import profileTpl from '../views/profile.html'

const render = () => {
  $('main').html(profileTpl)
}

export default {
  render
}